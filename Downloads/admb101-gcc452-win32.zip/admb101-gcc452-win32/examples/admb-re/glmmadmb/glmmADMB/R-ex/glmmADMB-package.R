### Name: glmmADMB-package
### Title: What the package does (short line) ~~ package title ~~
### Aliases: glmmADMB-package glmmADMB
### Keywords: package

### ** Examples

~~ simple examples of the most important functions ~~



